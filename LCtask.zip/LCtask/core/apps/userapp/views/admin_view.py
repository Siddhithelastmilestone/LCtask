from django.shortcuts import render,redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib import messages
from django.contrib.auth import logout


def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        print(email, password)
        if not email or not password:
            messages.error(request, 'Please provide both email and password')
            return render(request, "login.html")
        
        try:
            user = authenticate(request, email=email, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('index')
            else:
                messages.error(request, 'Invalid username or password')
        except Exception as e:
            print(f"Exception during login: {e}")
            messages.error(request, 'An error occurred while trying to login')
    return render(request, "login.html")
    
def index(request):
    return render(request,"index.html")

def logout_view(request):
    logout(request)
    return redirect('/')
    


