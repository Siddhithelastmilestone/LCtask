from django.urls import path
from apps.userapp.views.admin_view import *

urlpatterns = [
  
    path("",login ,name='login'),
    path("index",index ,name='index'),
    path('logout', logout, name='logout'),
]