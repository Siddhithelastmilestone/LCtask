from django.shortcuts import render,redirect

from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework import status
from rest_framework import generics
from django.views import View
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth import logout

from django.contrib import messages
from apps.ecommerce.models import *
from apps.ecommerce.serializers import *

# Create your views here

class CategoryAPIViews(APIView):

    def post(self, request, format=None):
        try:
            data = request.data
            category_name = data.get("category_name") 
            description = data.get("description") 
            
            if CategoryView.objects.filter(category_name=category_name).exists():
                return Response("This Category name is already in database")
            else:
                CategoryView.objects.create(category_name=category_name, description=description)
                return Response("Category create successfuly")
        except:
            return Response("Something went wrong!")
        
    def get(self, request, format=None, category_id=None):
        try:
            if category_id is None:  
                category_obj = CategoryView.objects.all()
                serializers_obj=CategorySerializer(category_obj,many=True).data
                return Response(serializers_obj)
            else:
                category_obj = CategoryView.objects.get(id=category_id)
                serializers_obj=CategorySerializer(category_obj).data
                return Response(serializers_obj)
        except:
            return Response("Something went wrong!")
        
    def delete(self, request, category_id=None):
        try:
            category_obj=CategoryView.objects.get(id=category_id)
            category_obj.delete()
            return Response("Category data deleted successfuly")
        except:
            return Response("Something went wrong!")
        
    def put(self, request, category_id=None):
        try:
            data = request.data
            category_name=data.get("category_name")
            description=data.get("description")

            category_obj = CategoryView.objects.get(id=category_id)
            if category_name:
                category_obj.category_name=category_name  
            if description:
                category_obj.description=description
            category_obj.save()
            return Response("Category update successfully")        
        except:
            return Response("Something went wrong!")

class SubCategoryAPIViews(APIView):
    
    def post(self, request):
        try:
            data = request.data
            subcategory_name = data.get("subcategory_name")
            description = data.get("description")
            category_id = data.get("category_id")

            if SubCategoryView.objects.filter(id=category_id).exists():
                category_master_obj = SubCategoryView.objects.get(id=category_id)
                            
                if SubCategoryView.objects.filter(category_id=category_id, subcategory_name=subcategory_name).exists():
                    return Response("Sub-Category already added for this category")
                else:
                    SubCategoryView.objects.create(category_id=category_master_obj.id, subcategory_name=subcategory_name, description=description)
                    return Response("Sub-Category created successfully")
            else:
                return Response("Category id is not match")            
        except:
            return Response("Something went wrong!")
    
    def get(self, request, category_id=None, subcategory_id=None):
        try:
            if category_id is not None:
                category_master_obj = CategoryView.objects.get(id=category_id)

                if subcategory_id is not None:
                    subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id, category_id=category_master_obj)
                    serializers_obj = SubCategorySerializer(subcategory_master_obj).data
                    return Response(serializers_obj)
                else:
                    subcategory_master_obj = SubCategoryView.objects.filter(category_id=category_master_obj)
                    serializers_obj = SubCategorySerializer(subcategory_master_obj, many=True).data
                    return Response(serializers_obj)
            else:
                return Response("Category ID is required")
        except:
            return Response("Something went wrong!")
        
    def delete(self, request, category_id=None, subcategory_id=id):
        try:
            subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id)
            subcategory_master_obj.delete()
            return Response("Sub-Category Data Deleted Successfully")
        except:
            return Response("Something went wrong!")
    
    def put(self, request, category_id=None, subcategory_id=None):
        try:
            if subcategory_id is not None:
                data = request.data
                subcategory_name = data.get("subcategory_name")
                description = data.get("description")

                category_master_obj = CategoryView.objects.get(id=category_id)
                subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id, category_id=category_master_obj)

                if subcategory_name:
                    subcategory_master_obj.subcategory_name = subcategory_name

                if description:
                    subcategory_master_obj.description = description

                subcategory_master_obj.save()
                return Response("Sub-Category updated successfully")
            else:
                return Response("Sub-category ID is required")
        except:
            return Response("Something went wrong:")

class ProductAPIViews(APIView):

    def post(self, request, category_id=None, subcategory_id=None, product_id=None):
        try:
           
            data = request.data
            subcategory_id = data.get("subcategory_id")
            product_name = data.get("product_name")
            description = data.get("description")
            price = data.get("price")
            stock_quantity = data.get("stock_quantity")
            main_image = request.FILES.get("main_image")

            if SubCategoryView.objects.filter(id=subcategory_id).exists():
                subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id)

                if ProductView.objects.filter(subcategory_id=subcategory_id, product_name=product_name).exists():
                    return Response("Product Is Already In This Category And Sub-Category ")
                else:
                    ProductView.objects.create(
                        subcategory_id=subcategory_master_obj.id,
                        product_name=product_name,
                        description=description,
                        price=price,
                        stock_quantity=stock_quantity,
                        main_image=main_image
                    )
                    return Response("Product Created Successfully")
            else:
                return Response("Sub-category ID is required")
        except:
            return Response("Something went wrong!")

    def get(self, request, category_id=None, subcategory_id=None, product_id=None):
        try:

                if subcategory_id is not None:
                    subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id)

                    if product_id is not None:
                        product_master_obj = ProductView.objects.get(id=product_id, subcategory_id=subcategory_master_obj)
                        serializers_obj = ProductSerializer(product_master_obj).data
                        return Response(serializers_obj)
                    else:
                        product_master_obj = ProductView.objects.filter(subcategory_id=subcategory_master_obj)
                        serializers_obj = ProductSerializer(product_master_obj, many=True).data
                        return Response(serializers_obj)
                else:
                    return Response("Sub-Category ID is required")
            
        except:
            return Response("Something went wrong!")

    def delete(self, request, category_id=None, subcategory_id=None, product_id=None):
        try:
            if product_id is not None:
                product_master_obj = ProductView.objects.get(id=product_id)
                product_master_obj.delete()
                return Response("Product deleted successfully")
            else:
                return Response("Product ID is required")
        except:
            return Response("Something went wrong!")

    def put(self, request, category_id=None, subcategory_id=None, product_id=None):
        try:
            if product_id is not None:
                data = request.data
                product_name = data.get("product_name")
                description = data.get("description")
                price = data.get("price")
                stock_quantity = data.get("stock_quantity")
                main_image = request.FILES.get("main_image")

                subcategory_master_obj = SubCategoryView.objects.get(id=subcategory_id)
                product_master_obj = ProductView.objects.get(id=product_id, subcategory_id=subcategory_master_obj)

                if product_name:
                    product_master_obj.product_name=product_name
                if description:
                    product_master_obj.description=description
                if price:
                    product_master_obj.price=price
                if stock_quantity:
                    product_master_obj.stock_quantity=stock_quantity
                if main_image:
                    product_master_obj.main_image=main_image

                product_master_obj.save()
                return Response("Product updated successfully")
            else:
                return Response("Product ID is required")
        except:
            return Response("Something went wrong!")