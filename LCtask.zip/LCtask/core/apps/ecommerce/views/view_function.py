from django.shortcuts import render,redirect
from apps.ecommerce.models import *
##############
def index(request):
 return render(request, 'index.html')

def CategoryView(request):
    categoryobj = Category.objects.all()
    context={
        "categoryobj":categoryobj
    }
    return render(request,"category.html",context)


def AddCatagory(request):
    if request.method == "POST":
        category_name= request.POST["category_name"]
        description= request.POST["description"]
        Category.objects.create(category_name=category_name,description=description)
        return redirect("/category")
    return render(request,"category.html")

def DeleteCategory(request,id):
    try:
        Category.objects.get(id=id).delete()
        return redirect("category")
    except Category.DoesNotExist:
        return redirect("category")
    

def UpdateCategory(request,id):
    if request.method=="POST":
        categoryobj = Category.objects.get(id=id)
        categoryobj.category_name = request.POST["category_name"]
        categoryobj.description = request.POST["description"]
        categoryobj.save()
        return redirect("category")
    return render(request,"category.html")


##########################################################################################
######SUBCATEGORY#######


def SubCategoryView(request):
    subcategoryobj = SubCategory.objects.all()
    categoryobj = Category.objects.all()
    context={
        "subcategoryobj":subcategoryobj,
        "categoryobj":categoryobj
    }
    return render(request,"subcategory.html",context)


def AddSubCatagory(request):
    categoryobj = Category.objects.all()
    if request.method == "POST":
        categoryid = request.POST["category_id"]
        subcategory_name= request.POST["subcategory_name"]
        description= request.POST["description"]
        categoryobj = Category.objects.get(id=categoryid)
        context = {
            'categoryobj' : categoryobj,
        }
        SubCategory.objects.create(subcategory_name=subcategory_name,description=description,category_id=categoryobj)
        return redirect("/subcategory")
    return render(request,"subcategory.html",context)

def DeleteSubCategory(request,id):
    try:
        SubCategory.objects.get(id=id).delete()
        return redirect("subcategory")
    except Category.DoesNotExist:
        return redirect("subcategory")
    

def update_subcategory(request, id):
    subcategoryobj = SubCategory.objects.get(id=id)
    if request.method == "POST":
        subcategory_name = request.POST["subcategory_name"]
        description = request.POST["description"]
        

        subcategoryobj.subcategory_name = subcategory_name
        subcategoryobj.description = description
        subcategoryobj.save()
        return redirect("/subcategory")
    context = {
        "subcategoryobj": subcategoryobj
    }
    return render(request, "update_subcategory.html",context)
   




##################################*****PRODUCT*****################################################


def ProductView(request):
    productobj = Product.objects.all()
    categoryobj = Category.objects.all()
    subcategoryobj = SubCategory.objects.all()
    context={
        "productobj":productobj,
        "categoryobj" : categoryobj,
        "subcategoryobj":subcategoryobj,
    }

    return render(request,"product.html",context)

def AddProduct(request):
    subcategoryobj = SubCategory.objects.all()
    if request.method == "POST":
        sub_categoryid= request.POST["sub_category_id"]
        product_name= request.POST["product_name"]
        description= request.POST["description"]
        price= request.POST["price"]
        stock_quantity= request.POST["stock_quantity"]
        subcategoryobj = SubCategory.objects.get(id=sub_categoryid)
        Product.objects.create(sub_category_id=subcategoryobj,product_name=product_name,description=description,price=price,stock_quantity=stock_quantity)
        return redirect("/product")
        
    return render(request,"product.html")       

def DeleteProduct(request,id):
    try:
        Product.objects.get(id=id).delete()
        return redirect("product")
    except Category.DoesNotExist:
        return redirect("product")
    
def update_product(request, id):
    productobj = Product.objects.get(id=id)
    if request.method == "POST":
        product_name = request.POST["product_name"]
        description = request.POST["description"]
        price = request.POST["price"]
        stock_quantity = request.POST["stock_quantity"]

        productobj.product_name = product_name
        productobj.description = description
        productobj.price = price
        productobj.stock_quantity = stock_quantity
        productobj.save()
        return redirect("/product")
    context = {
        "productobj": productobj
    }
    return render(request, "update_product.html",context)
        