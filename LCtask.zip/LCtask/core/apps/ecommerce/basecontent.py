from django.db import models
# from datetime import datetime
# from apps.userapp.models import *

class BaseContent(models.Model):
    created_date = models.DateTimeField(auto_now_add=True)
    last_updated_date = models.DateTimeField(auto_now_add=True)
    is_active = models.BooleanField(default=True)
    # last_updated_by = models.ForeignKey(to=UserAuth , on_delete=models.CASCADE)

    class Meta:
        abstract = True