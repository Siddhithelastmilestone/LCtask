from rest_framework import serializers
from . models import *

class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoryView
        fields = "__all__"

class SubCategorySerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(read_only=True, source="category.category_name")
    category_description = serializers.CharField(read_only=True, source="category.description")    
    class Meta:
        model = SubCategoryView
        fields = "__all__"

class ProductSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(read_only=True, source="category.category_name")
    category_description = serializers.CharField(read_only=True, source="category.description")

    subcategory_name = serializers.CharField(read_only=True, source="subcategory.subcategory_name")
    subcategory_description = serializers.CharField(read_only=True, source="subcategory.description") 
    class Meta:
        model = ProductView
        fields = "__all__"