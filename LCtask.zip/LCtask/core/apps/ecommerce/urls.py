from django.urls import path
from apps.ecommerce.views.api_view import *
from apps.ecommerce.views.view_function import *

# from django.contrib.auth import views as auth_views




urlpatterns = [

    path('category/',CategoryView, name='category'),
    path('add_category/',AddCatagory, name='add_category'),
    path('delete_category/<int:id>/',DeleteCategory, name='delete_category'),
    path('update_category/<int:id>/',UpdateCategory, name='update_category'),
    
    path('subcategory/',SubCategoryView, name='subcategory'),
    path('add_subcategory/',AddSubCatagory, name='add_subcategory'),
    path('delete_subcategory/<int:id>/',DeleteSubCategory, name='delete_subcategory'),
    path('update_subcategory/<int:id>/',update_subcategory, name='update_subcategory'),

    path('product/',ProductView, name='product'),
    path('add_product/',AddProduct, name='add_product'),
    path('delete_product/<int:id>/',DeleteProduct, name='delete_product'),
    path('update_product/<int:id>/',update_product, name='update_product'),

# categorymaster
    path('categorymaster/',CategoryAPIViews.as_view(), name='categorymaster'),
    path('categorymaster/<int:category_id>/', CategoryAPIViews.as_view(), name='categorymaster'),


    # subcategorymaster
    path('subcategorymaster/', SubCategoryAPIViews.as_view(),name='subcategorymaster'),
    path('categorymaster/<int:category_id>/subcategorymaster/', SubCategoryAPIViews.as_view(),name='subcategorymaster'),
    path('categorymaster/<int:category_id>/subcategorymaster/<int:subcategory_id>/', SubCategoryAPIViews.as_view(),name='subcategorymaster'),

    # productmaster
    path('productmaster/', ProductAPIViews.as_view(),name='productmaster'),
    path('categorymaster/<int:category_id>/subcategorymaster/<int:subcategory_id>/productmaster/', ProductAPIViews.as_view(),name='productmaster'),
    path('categorymaster/<int:category_id>/subcategorymaster/<int:subcategory_id>/productmaster/<int:product_id>/', ProductAPIViews.as_view(), name='productmaster'),
]