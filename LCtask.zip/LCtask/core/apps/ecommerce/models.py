from django.db import models

# Create your models here.
class Category(models.Model):
    category_name = models.CharField(max_length=100)
    description = models.TextField()

class SubCategory(models.Model):
    category_id = models.ForeignKey(Category, related_name='subcategories', on_delete=models.CASCADE)
    subcategory_name = models.CharField(max_length=100)
    description = models.TextField()


class Product(models.Model):
    sub_category_id = models.ForeignKey(SubCategory, on_delete=models.CASCADE)
    product_name = models.CharField(max_length=100)
    description = models.TextField()
    price = models.IntegerField()
    stock_quantity = models.IntegerField()

####################################################
class CategoryView(models.Model):
    category_name= models.CharField(max_length=250, blank=True,null=True,default=True)
    description= models.TextField(blank=True,null=True,default=True)
   
    def __str__(self):
        return self.category_name
 
class SubCategoryView(models.Model):
    category = models.ForeignKey(to=CategoryView, on_delete=models.CASCADE)
    subcategory_name= models.CharField(max_length=250, blank=True,null=True,default=True)
    description= models.TextField(blank=True,null=True,default=True)
 
    def __str__(self):
        return self.subcategory_name
 
class ProductView(models.Model):
    subcategory = models.ForeignKey(to=SubCategoryView, on_delete=models.CASCADE)
    product_name=models.CharField(max_length=250, blank=True,null=True,default=True)
    description= models.TextField(blank=True,null=True,default=True)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    stock_quantity = models.PositiveIntegerField()
    main_image = models.ImageField(upload_to='Product Main Image',blank=True, null=True)
 
    def __str__(self):
        return self.product_name